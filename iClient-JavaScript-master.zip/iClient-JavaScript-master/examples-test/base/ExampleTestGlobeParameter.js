﻿GlobeParameter = {
    datajingjinURL: "http://localhost:8090/iserver/services/data-jingjin/rest/data/datasources/Jingjin/datasets/",
    datachangchunURL: "http://localhost:8090/iserver/services/data-changchun/rest/data/datasources/Changchun/datasets/",
    dataspatialAnalystURL: "http://localhost:8090/iserver/services/data-spatialAnalyst/rest/data/datasources/Interpolation/datasets/"
};